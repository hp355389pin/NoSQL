文件說明

本資料集為NoSQL課程之學習筆記，包含MongoDB及Redis兩大主題。
依據主題及關聯編排為十章節，採文字概念筆記、實作指令程式並重而撰。


茲列章節綱要:

Lecture 01　MongoDB 101
Lecture 02　數據庫(database)
Lecture 03　集合表(collection)
Lecture 04　資料檔(document)(1):新增
Lecture 05　資料檔(document)(2):查詢
Lecture 06　資料檔(document)(3):修改、刪除
Lecture 07　索引
Lecture 08　資料管理
Lecture 09　Redis 101
Lecture 10　實例應用
